truncate table ilc_workbook_purchase_user;
truncate table ilc_workbook_chapter_exercise_item_answer;
truncate table ilc_workbook_chapter_exercise_item;
truncate table ilc_workbook_chapter_exercise;
truncate table ilc_workbook_chapter;
truncate table ilc_workbook;



